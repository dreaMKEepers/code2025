// package org.firstinspires.ftc.teamcode;
// 
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
// 
// @TeleOp(name = "grab (Blocks to Java)")
// 
// public class GrabText extends LinearOpMode {
// 
//   /**
//    * This function is executed when this OpMode is selected from the Driver Station.
//    */
//   @Override
//   public void runOpMode() {
//     grab = hardwareMap.get();
//     // Put initialization blocks here.
//     waitForStart();
//     if (opModeIsActive()) {
//       // Put run blocks here.
//       while (opModeIsActive()) {
//         if (gamepad1.b) {
//           telemetry.update();
//         }
//       }
//     }
//   }
// }