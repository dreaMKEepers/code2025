package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp(name = "LiftBody (Blocks to Java)")
public class LiftBodyLinearActuator extends LinearOpMode {

  private DcMotor backLeftMotor;

  /**
   * This function is executed when this OpMode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    backLeftMotor = hardwareMap.get(DcMotor.class, "CHANGEME!");

    // Put initialization blocks here.
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        if (gamepad1.a) {
          backLeftMotor.setPower(1);
        } else {
          backLeftMotor.setPower(0);
        }
        // Put loop blocks here.
        telemetry.update();
      }
    }
  }
}