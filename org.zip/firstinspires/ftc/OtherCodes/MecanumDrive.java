// package org.firstinspires.ftc.strafer.mechanisms;
// 
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.HardwareMap;
// 
// @TeleOp
// 
// 
// public class MecanumDrive {
// 
//     private DcMotor frontLeftMotor;
//     private DcMotor frontRightMotor; 
//     private DcMotor backLeftMotor; 
//     private DcMotor backRightMotor; 
//     
//     public void init (HardwareMap hardwareMap) {
//         frontLeftMotor = hardwareMap.dcMotor.get("front_left_motor"); 
//         frontRightMotor = hardwareMap.dcMotor.get("front_right_motor");
//         backLeftMotor = hardwareMap.dcMotor.get("back_left_motor");
//         backRightMotor = hardwareMap.dcMotor.get("back_right_motor");
//         
//         //backLeftMotor.setDirection(DcMotor.Direction.Reverse);
//         //frontLeftMotor.setDirection(DcMotor.Direction.Reverse);
//         
//         frontLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         frontRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         backLeftMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//         backRightMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
//     }
// 
// }
// 
