package org.firstinspires.ftc.OtherCodes;

import com.qualcomm.robotcore.hardware.DcMotor;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
@TeleOp(name = "Autonomous")
public class Autonomous extends LinearOpMode{
    public DcMotor frontLeftMotor = hardwareMap.dcMotor.get("frontLeftMotor");
    public DcMotor backLeftMotor = hardwareMap.dcMotor.get("backLeftMotor");
    public DcMotor frontRightMotor = hardwareMap.dcMotor.get("frontRightMotor");
    public DcMotor backRightMotor = hardwareMap.dcMotor.get("backRightMotor");
    public DcMotor odometryPodX = hardwareMap.dcMotor.get("frontLeftMotor");
    
    double podDiameter = 48; // diameter in mm
    double podCircumference = Math.PI*podDiameter;
    double encoderResolution = 2000; // 2000 pulses per one revolution
    double mmToInches = 0.039;
    double pulsesToInches = mmToInches*podCircumference/encoderResolution; // Conversion factor for the number of pulses per 1 mm
    
    
    @Override
    public void runOpMode() throws InterruptedException {
        // Declare our motors
        // Make sure your ID's match your configuration
        // Reverse the right side motors. This may be wrong for your setup.
        // If your robot moves backwards when commanded to go forwards,
        // reverse the left side instead.
        // See the note about this earlier on this page.
        frontRightMotor.setDirection(DcMotorSimple.Direction.REVERSE);
        backRightMotor.setDirection(DcMotorSimple.Direction.REVERSE);

        waitForStart();
        moveX(12,0.2);
        
        if (isStopRequested()) return;

        while (opModeIsActive()) {

        }
    }
    void moveX(double distance, double power){
        
        while (odometryPodX.getCurrentPosition() < distance/pulsesToInches){
            frontLeftMotor.setPower(power);
            frontRightMotor.setPower(power);
            backLeftMotor.setPower(power);
            backRightMotor.setPower(power);
        }
    }
    
}
