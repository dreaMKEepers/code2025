package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp(name = "LinearActuator")
public class LinearActuator extends LinearOpMode {

  private DcMotor actuator;

  /**
   * This function is executed when this OpMode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    actuator = hardwareMap.get(DcMotor.class, "actuator");

    // Put initialization blocks here.
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        if (gamepad1.y) {
          actuator.setPower(50);
        } else {
          actuator.setPower(0);
        }
        // Put loop blocks here.
        telemetry.update();
        if(gamepad1.a) {
          actuator.setPower(-50);
        }
      }
    }
  }
}
