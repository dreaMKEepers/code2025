// package org.firstinspires.ftc.teamcode;
// // import com.acrobotics.ftclib.hardware.motors;
// 
// import com.qualcomm.robotcore.eventloop.opmode.Disabled;
// import com.qualcomm.hardware.dfrobot.HuskyLens;
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.util.Range;
// import org.firstinspires.ftc.robotcore.external.hardware.camera.BuiltinCameraDirection;
// import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
// import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.ExposureControl;
// import org.firstinspires.ftc.robotcore.external.hardware.camera.controls.GainControl;
// import org.firstinspires.ftc.vision.VisionPortal;
// import org.firstinspires.ftc.vision.apriltag.AprilTagDetection;
// import org.firstinspires.ftc.vision.apriltag.AprilTagProcessor;
// import com.qualcomm.robotcore.hardware.DcMotorSimple;
// @Autonomous(name="AutonomousPractice", group="Pratice")
// public class Autonomous_practice extends LinearOpMode{
//     
//     DcMotor frontLeftMotor;
//     DcMotor backLeftMotor;
//     DcMotor frontRightMotor;
//     DcMotor backRightMotor;
//     
//     @Override
//     public void runOpMode() throws InterruptedException {
//         //Declare Motors
//         DcMotor frontLeftMotor = hardwareMap.dcMotor.get("frontLeftMotor");
//         DcMotor backLeftMotor = hardwareMap.dcMotor.get("backLeftMotor");
//         DcMotor frontRightMotor = hardwareMap.dcMotor.get("frontRightMotor");
//         DcMotor backRightMotor = hardwareMap.dcMotor.get("backRightMotor");
//         //Set Directions
//         frontRightMotor.setDirection(DcMotorSimple.Direction.FORWARD);
//         backRightMotor.setDirection(DcMotorSimple.Direction.FORWARD);
//         frontLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
//         backLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
//         // AprilTag and Huskey Lens
//         HuskyLens HuskyLens = hardwareMap.get(HuskyLens.class, "HuskyLens");
//                 
//         waitForStart();
//         
//         while (opModeIsActive()) {
//             
//         // frontLeftMotor.setPower(0.2);
//         // backLeftMotor.setPower(0.2);
//         // frontRightMotor.setPower(0.2);
//         // backRightMotor.setPower(0.2);
//         telemetry.addData("Is it on bro?", "its on");
//         telemetry.addData("Target Position", backRightMotor.getTargetPosition());
//         backRightMotor.setPower(0.7);
//         telemetry.addData("Target Position 2", backRightMotor.getTargetPosition());
//         // sleep(10000);
//         
//         // frontLeftMotor.setPower(0);
//         // backLeftMotor.setPower(0);
//         // frontRightMotor.setPower(0);
//         // backRightMotor.setPower(0);
//         }
//          telemetry.update();
//     }
// }