package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;

@TeleOp(name="CoreHex", group="Test")
public class CoreHex extends OpMode {

    DcMotor motorTest = null;

    @Override
    public void init() {
      motorTest = hardwareMap.get(DcMotor.class, "motorTest");
    }

    @Override
    public void loop() {
        motorTest.setPower(gamepad1.right_stick_y);
        telemetry.addData("position", motorTest.getCurrentPosition());
    }
}