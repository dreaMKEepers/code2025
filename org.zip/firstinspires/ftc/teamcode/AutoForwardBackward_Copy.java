// package org.firstinspires.ftc.teamcode;
// 
// import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
// import com.qualcomm.robotcore.hardware.DcMotor;
// import com.qualcomm.robotcore.hardware.DcMotorSimple;
// import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// 
// @Autonomous(name="AutoForwardBackward")
// public class AutoForwardBackward_Copy extends LinearOpMode{
//     
//     @Override
//     public void runOpMode() throws InterruptedException{
//     DcMotor frontLeftMotor = hardwareMap.dcMotor.get("frontLeftMotor");
//     DcMotor backLeftMotor = hardwareMap.dcMotor.get("backLeftMotor");
//     DcMotor frontRightMotor = hardwareMap.dcMotor.get("frontRightMotor");
//     DcMotor backRightMotor = hardwareMap.dcMotor.get("backRightMotor");
//     
//     frontRightMotor.setDirection(DcMotorSimple.Direction.FORWARD);
//     backRightMotor.setDirection(DcMotorSimple.Direction.FORWARD);
//     frontLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
//     backLeftMotor.setDirection(DcMotorSimple.Direction.REVERSE);
// 
//     waitForStart();
//     if(opModeIsActive()) {
//     frontRightMotor.setPower(0.5);
//     frontLeftMotor.setPower(0.5);
//     backRightMotor.setPower(0.5);
//     backLeftMotor.setPower(0.5);
//     Thread.sleep(1000);
//     frontRightMotor.setPower(0);
//     frontLeftMotor.setPower(0);
//     backRightMotor.setPower(0);
//     backLeftMotor.setPower(0);
//     }
// }
// }
// 